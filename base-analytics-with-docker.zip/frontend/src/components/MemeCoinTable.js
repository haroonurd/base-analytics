import React from "react";
import { LineChart, Line, Tooltip, ResponsiveContainer } from "recharts";

export default function MemeCoinTable({ coins }) {
  return (
    <div className="mt-6">
      <h2 className="text-xl font-semibold mb-3">Top Meme Coins</h2>
      <div className="overflow-x-auto bg-white p-4 rounded shadow">
        <table className="min-w-full">
          <thead className="bg-gray-100">
            <tr>
              <th className="p-2 text-left">Name</th>
              <th className="p-2">Price (USD)</th>
              <th className="p-2">24h Volume</th>
              <th className="p-2">Change (24h)</th>
              <th className="p-2">Change (7d)</th>
              <th className="p-2">Change (30d)</th>
              <th className="p-2">Trend</th>
            </tr>
          </thead>
          <tbody>
            {coins.map((coin) => (
              <tr key={coin.id} className="border-t hover:bg-gray-50">
                <td className="p-2 flex items-center gap-2">
                  <img src={coin.image} alt={coin.name} className="w-6 h-6" />
                  <div>
                    <div className="font-medium">{coin.name}</div>
                    <div className="text-xs text-gray-500">{coin.symbol.toUpperCase()}</div>
                  </div>
                </td>
                <td className="p-2 text-right">${coin.current_price.toFixed(4)}</td>
                <td className="p-2 text-right">${coin.total_volume.toLocaleString()}</td>
                <td className={`p-2 text-right ${coin.price_change_percentage_24h>0? 'text-green-600':'text-red-600'}`}>
                  {coin.price_change_percentage_24h?.toFixed(2)}%
                </td>
                <td className="p-2 text-right">{coin.price_change_percentage_7d_in_currency?.toFixed(2)}%</td>
                <td className="p-2 text-right">{coin.price_change_percentage_30d_in_currency?.toFixed(2)}%</td>
                <td className="p-2 w-40">
                  <ResponsiveContainer width="100%" height={40}>
                    <LineChart data={(coin.sparkline_in_7d?.price || []).map((p)=>({p}))}>
                      <Line type="monotone" dataKey="p" dot={false} />
                      <Tooltip />
                    </LineChart>
                  </ResponsiveContainer>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
