import React from "react";
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";

export default function VolumeChart({ coins }) {
  // coins: array from CoinGecko containing total_volume and sparkline
  const top = coins.slice(0,8);
  // Prepare a small series: use last 24 sparkline points average as indicator (approx)
  const data = top.map(c => ({ name: c.symbol.toUpperCase(), volume: c.total_volume }));
  return (
    <div className="mt-6 bg-white p-4 rounded shadow">
      <h3 className="font-medium mb-3">Top Meme Coin Volumes (24h)</h3>
      <div style={{ width: '100%', height: 240 }}>
        <ResponsiveContainer>
          <AreaChart data={data}>
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            <Area type="monotone" dataKey="volume" />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
