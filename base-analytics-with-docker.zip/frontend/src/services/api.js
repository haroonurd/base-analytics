import axios from 'axios';
const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:4000';

export const getMemeCoins = () => axios.get(`${API_URL}/api/memecoins`);
export const getTransactions = (wallet) => axios.get(`${API_URL}/api/transactions/${wallet}`);
export const getWalletBalances = (wallet) => axios.get(`${API_URL}/api/wallet/${wallet}`);
