import React from "react";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";

export default function WalletAnalytics({ balances }) {
  // balances: [{ tokenSymbol, balance, price, valueUsd, change24h, change7d, change30d }]
  // We'll prepare a simple bar of top holdings and a line showing hypothetical value over periods using percent changes.
  const top = balances.slice().sort((a,b)=> (b.valueUsd||0)-(a.valueUsd||0)).slice(0,8);

  // build time series for total wallet value using aggregated percent changes.
  // This is an approximation: we compute current total, then back-calculate approximate past totals using price change %
  const nowTotal = balances.reduce((s,b)=> s + (b.valueUsd||0), 0);
  const total24h = balances.reduce((s,b)=> s + ((b.valueUsd!=null && b.change24h!=null) ? (b.valueUsd / (1 + b.change24h/100)) : (b.valueUsd||0)), 0);
  const total7d = balances.reduce((s,b)=> s + ((b.valueUsd!=null && b.change7d!=null) ? (b.valueUsd / (1 + b.change7d/100)) : (b.valueUsd||0)), 0);
  const total30d = balances.reduce((s,b)=> s + ((b.valueUsd!=null && b.change30d!=null) ? (b.valueUsd / (1 + b.change30d/100)) : (b.valueUsd||0)), 0);

  const series = [
    { period: '30d ago', value: Number(total30d.toFixed(2)) },
    { period: '7d ago', value: Number(total7d.toFixed(2)) },
    { period: '24h ago', value: Number(total24h.toFixed(2)) },
    { period: 'Now', value: Number(nowTotal.toFixed(2)) },
  ];

  return (
    <div className="mt-6 bg-white p-4 rounded shadow">
      <h2 className="text-xl font-semibold mb-3">Wallet Analytics</h2>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <h3 className="font-medium">Top Holdings (USD)</h3>
          <ul className="mt-2 space-y-2">
            {top.map(t=>(
              <li key={t.contract} className="flex justify-between">
                <div>
                  <div className="font-medium">{t.tokenSymbol || t.tokenName}</div>
                  <div className="text-xs text-gray-500">{t.balance} {t.tokenSymbol}</div>
                </div>
                <div className="text-right">
                  <div className="font-medium">${(t.valueUsd||0).toFixed(2)}</div>
                  <div className="text-xs text-gray-500">{t.price? `$${t.price.toFixed(6)}` : 'no price'}</div>
                </div>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h3 className="font-medium">Total Wallet Value (approx)</h3>
          <div style={{ width: '100%', height: 200 }}>
            <ResponsiveContainer>
              <LineChart data={series}>
                <XAxis dataKey="period" />
                <YAxis />
                <Tooltip />
                <Line type="monotone" dataKey="value" dot />
              </LineChart>
            </ResponsiveContainer>
          </div>
          <div className="mt-2 text-sm text-gray-600">
            Note: past values are approximated using price change percentages from CoinGecko where available.
          </div>
        </div>
      </div>
    </div>
  );
}
