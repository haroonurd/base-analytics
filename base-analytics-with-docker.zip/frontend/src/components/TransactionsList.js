import React from "react";

export default function TransactionsList({ transactions }) {
  return (
    <div className="mt-6">
      <h2 className="text-xl font-semibold mb-3">Recent Transactions</h2>
      <div className="bg-white p-4 rounded shadow">
        <ul className="space-y-2">
          {transactions.map((tx) => (
            <li key={tx.hash} className="border p-2 rounded">
              <div className="text-sm"><span className="font-semibold">Hash:</span> {tx.hash}</div>
              <div className="text-xs text-gray-600">Block: {tx.blockNumber} | Value: {(Number(tx.value)/1e18).toFixed(6)} ETH</div>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
