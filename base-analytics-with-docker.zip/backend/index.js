import express from "express";
import axios from "axios";
import cors from "cors";
import dotenv from "dotenv";
import Database from "better-sqlite3";
import path from "path";
import { fileURLToPath } from "url";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const dbPath = process.env.SQLITE_DB_PATH || path.join(__dirname, 'cache.db');
const db = new Database(dbPath);

db.exec(`
CREATE TABLE IF NOT EXISTS cache (
  key TEXT PRIMARY KEY,
  value TEXT,
  expires_at INTEGER
);
`);

function setCache(key, value, ttlSeconds=60) {
  const expires_at = Math.floor(Date.now()/1000) + ttlSeconds;
  const stmt = db.prepare('INSERT OR REPLACE INTO cache (key, value, expires_at) VALUES (?, ?, ?)');
  stmt.run(key, JSON.stringify(value), expires_at);
}

function getCache(key) {
  const row = db.prepare('SELECT value, expires_at FROM cache WHERE key = ?').get(key);
  if (!row) return null;
  if (row.expires_at < Math.floor(Date.now()/1000)) {
    // expired
    db.prepare('DELETE FROM cache WHERE key = ?').run(key);
    return null;
  }
  try { return JSON.parse(row.value); } catch(e){ return null; }
}

const app = express();
app.use(cors());
app.use(express.json());

const BASESCAN_API = process.env.BASESCAN_API || "https://api.basescan.org/api";
const BASESCAN_KEY = process.env.BASESCAN_KEY || "";
const COINGECKO_PLATFORM = process.env.COINGECKO_PLATFORM || "base";
const COINGECKO_API = "https://api.coingecko.com/api/v3";

function errorResponse(res, msg, err) {
  console.error(msg, err?.toString?.() ?? err);
  return res.status(500).json({ error: msg });
}
function errorResponse(res, msg, err) {
  console.error(msg, err?.toString?.() ?? err);
  return res.status(500).json({ error: msg });
}

app.get("/api/transactions/:address", async (req, res) => {
  try {
    const { address } = req.params;
    const url = `${BASESCAN_API}?module=account&action=txlist&address=${address}&sort=desc&apikey=${BASESCAN_KEY}`;
    const { data } = await axios.get(url);
    return res.json({ success: true, result: data.result || [] });
  } catch (err) {
    return errorResponse(res, "Failed to fetch transactions", err);
  }
});

app.get("/api/wallet/:address", async (req, res) => {
  try {
    const { address } = req.params;
    const page = req.query.page || 1;
    const offset = req.query.offset || 1000;
    const url = `${BASESCAN_API}?module=account&action=tokentx&address=${address}&page=${page}&offset=${offset}&sort=asc&apikey=${BASESCAN_KEY}`;
    const { data } = await axios.get(url);
    const transfers = data.result || [];

    const balances = {};
    for (const t of transfers) {
      const contract = (t.contractAddress || "").toLowerCase();
      if (!contract) continue;
      const decimals = Number(t.tokenDecimal || 0);
      const tokenKey = contract;
      if (!balances[tokenKey]) {
        balances[tokenKey] = {
          contract,
          tokenSymbol: t.tokenSymbol || "",
          tokenName: t.tokenName || "",
          decimals,
          balanceRaw: BigInt(0)
        };
      }
      const value = BigInt(t.value || "0");
      if (t.to && t.to.toLowerCase() === address.toLowerCase()) {
        balances[tokenKey].balanceRaw += value;
      }
      if (t.from && t.from.toLowerCase() === address.toLowerCase()) {
        balances[tokenKey].balanceRaw -= value;
      }
    }

    // convert to human balances (number)
    const results = [];
    for (const k of Object.keys(balances)) {
      const b = balances[k];
      const divisor = BigInt(10) ** BigInt(b.decimals || 0);
      const intPart = b.balanceRaw / divisor;
      const fracPart = b.balanceRaw % divisor;
      const fracStr = fracPart.toString().rjust?.(b.decimals, "0") ?? fracPart.toString();
      // create approximate float
      const balanceFloat = Number(intPart.toString()) + (Number(fracPart.toString()) / (10 ** (b.decimals || 0)));
      results.push({
        contract: b.contract,
        tokenSymbol: b.tokenSymbol,
        tokenName: b.tokenName,
        decimals: b.decimals,
        rawBalance: b.balanceRaw.toString(),
        balance: balanceFloat
      });
    }

    // fetch prices from CoinGecko (simple/token_price)
    const contracts = results.map(r => r.contract).slice(0,50);
    const prices = {};
    try {
      if (contracts.length) {
        const chunkSize = 20;
        for (let i=0;i<contracts.length;i+=chunkSize){
          const chunk = contracts.slice(i,i+chunkSize).join(",");
          const url2 = `${COINGECKO_API}/simple/token_price/${COINGECKO_PLATFORM}?contract_addresses=${chunk}&vs_currencies=usd&include_24hr_change=true&include_7d_change=true&include_30d_change=true`;
          const { data: p } = await axios.get(url2);
          Object.assign(prices, p);
        }
      }
    } catch (err) {
      console.warn("CoinGecko price lookup failed", err?.toString?.());
    }

    const merged = results.map(r => {
      const p = prices[r.contract.toLowerCase()] || prices[r.contract] || null;
      const usd = p?.usd ?? null;
      const change24h = p?.usd_24h_change ?? null;
      const change7d = p?.usd_7d_change ?? null;
      const change30d = p?.usd_30d_change ?? null;
      const valueUsd = usd !== null ? (r.balance * usd) : null;
      return { ...r, price: usd, valueUsd, change24h, change7d, change30d };
    });

    return res.json({ success: true, balances: merged, transfers_count: transfers.length });
  } catch (err) {
    return errorResponse(res, "Failed to compute wallet balances", err);
  }
});

app.get("/api/memecoins", async (req, res) => {
  try {
    const url = `${COINGECKO_API}/coins/markets?vs_currency=usd&category=memes&order=volume_desc&per_page=50&page=1&sparkline=true&price_change_percentage=24h,7d,30d`;
    const { data } = await axios.get(url);
    return res.json({ success: true, coins: data });
  } catch (err) {
    return errorResponse(res, "Failed to fetch meme coins", err);
  }
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`Backend running on port ${PORT}`));
