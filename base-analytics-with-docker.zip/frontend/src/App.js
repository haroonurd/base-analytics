import React, { useEffect, useState } from "react";
import { getMemeCoins, getTransactions, getWalletBalances } from "./services/api";
import MemeCoinTable from "./components/MemeCoinTable";
import TransactionsList from "./components/TransactionsList";
import WalletAnalytics from "./components/WalletAnalytics";
import VolumeChart from "./components/VolumeChart";

function App(){
  const [coins, setCoins] = useState([]);
  const [transactions, setTransactions] = useState([]);
  const [walletBalances, setWalletBalances] = useState([]);
  const [wallet, setWallet] = useState("0x0000000000000000000000000000000000000000");

  useEffect(()=>{
    load();
  },[]);

  async function load(){
    try {
      const coinRes = await getMemeCoins();
      setCoins(coinRes.data.coins || []);
    } catch(e){ console.error(e); }

    try {
      const txRes = await getTransactions("0x742d35Cc6634C0532925a3b844Bc454e4438f44e");
      setTransactions(txRes.data.result || []);
    } catch(e){ console.error(e); }
  }

  async function loadWallet(){
    if(!wallet) return;
    try {
      const res = await getWalletBalances(wallet);
      setWalletBalances(res.data.balances || []);
    } catch(e){ console.error(e); }
  }

  return (
    <div className="max-w-6xl mx-auto p-6">
      <h1 className="text-3xl font-bold mb-4 text-center">Base Chain Analytics Dashboard</h1>

      <div className="grid md:grid-cols-3 gap-4 mb-6">
        <div className="md:col-span-2">
          <div className="flex gap-2">
            <input value={wallet} onChange={e=>setWallet(e.target.value)} placeholder="Wallet address" className="flex-1 p-2 rounded border" />
            <button onClick={loadWallet} className="px-4 py-2 bg-blue-600 text-white rounded">Load Wallet</button>
          </div>
          <WalletAnalytics balances={walletBalances} />
        </div>

        <div>
          <div className="bg-white p-4 rounded shadow">
            <h3 className="font-medium mb-2">Quick Wallet Summary</h3>
            <div className="text-sm text-gray-600">Enter a wallet and click "Load Wallet" to compute balances and approximate USD value changes (24h/7d/30d).</div>
          </div>
        </div>
      </div>

      <MemeCoinTable coins={coins} />
      <VolumeChart coins={coins} />
      <TransactionsList transactions={transactions} />
    </div>
  );
}

export default App;
